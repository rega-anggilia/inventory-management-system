document.addEventListener("DOMContentLoaded", function () {
    console.log("Aplikasi Inventory Management siap digunakan!");
});
